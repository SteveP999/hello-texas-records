# HTR Dynamic Stage Engine v2.6 Alternating Albums

Changes:
- Album 1: cover left, tracks right.
- Album 2: tracks left, cover right.
- Album 3: cover left, tracks right.
- Album Tracks art grid stays underneath the album block.
- Hero logo is much larger.
- About section is transparent over the background image.
- Parallax background system remains.

Required central assets:
D:\hello-texas-records\Roster Photos\
- <artist-id>-hero-photo.png
- <artist-id>-discography-bg.png
- <artist-id>-video-bg.png
- <artist-id>-photo-1.png
- <artist-id>-photo-2.png
- <artist-id>-photo-3.png

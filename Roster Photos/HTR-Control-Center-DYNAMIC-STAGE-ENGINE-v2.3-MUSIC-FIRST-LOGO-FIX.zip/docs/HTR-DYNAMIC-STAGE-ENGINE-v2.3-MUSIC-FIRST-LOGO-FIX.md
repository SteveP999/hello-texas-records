# HTR Dynamic Stage Engine v2.3 Music First Logo Fix

Fixes:
- Hero logo is much larger.
- Removed tiny center nav logo.
- Reduced dead space.
- Latest single appears immediately after hero.
- Video moved below music.
- Discography now renders album first, then Album Tracks song art under the album.
- Release/song art card sizing is consistent.
- Roster Photos are copied into images/artist for GitHub Pages.

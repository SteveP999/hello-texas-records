# HTR Dynamic Stage Engine v2.4 Mockup Music Carousel

Fixes:
- Brighter hero background.
- Larger hero logo.
- Music is primary.
- Latest single remains above video.
- Discography renders album first.
- Album Tracks are horizontal left/right scrolling song cards.
- Video section is below music.
- Bottom player still appears when playback starts.

# HTR Dynamic Stage Engine v2.8 Album Proportions Lock

Fixes the album/discography proportions.

Locked album layout:
- Album cover is about 320px wide.
- Song art cards are about 145-165px wide.
- Album cover is roughly 2x the song art card size.
- Album 1: cover left, tracks right.
- Album 2: tracks left, cover right.
- Album Tracks art grid stays below the album block.
- Track list is no longer part of the Album Tracks bar.

# HTR Dynamic Stage Engine v2.4 Parallax Sections

Adds parallax-style section backgrounds.

## Source assets

Put these in:
D:\hello-texas-records\Roster Photos\

Required / recommended:
- <artist-id>-hero-photo.png
- <artist-id>-discography-bg.png
- <artist-id>-video-bg.png
- <artist-id>-photo-1.png
- <artist-id>-photo-2.png
- <artist-id>-photo-3.png
- <artist-id>-roster-photo.png

## What the build does

Copies those assets into:
D:\<ArtistRepo>\images\artist\

Then generated HTML uses:
- Hero background: images/artist/<artist-id>-hero-photo.png
- Discography background: images/artist/<artist-id>-discography-bg.png
- Video background: images/artist/<artist-id>-video-bg.png

## Page structure

1. Hero with large logo over hero-photo
2. Latest Single on solid color
3. Discography over discography-bg
4. Video lower on page over video-bg
5. About on solid color
6. Photo strip

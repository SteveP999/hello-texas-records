# HTR Dynamic Stage Engine v2.7 Bright Logo Transparent

Changes:
- Hero logo made much larger and brighter.
- Hero background brightened.
- Discography background brightened.
- Video section background brightened.
- Video box/bar made transparent over background.
- About section made transparent over background.
- Existing parallax/alternating album system preserved.

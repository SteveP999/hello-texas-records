# HTR Dynamic Stage Engine v2.1 Roster Assets

This fixes the asset-location drift.

## Locked rules

Artist repo:
- images/covers/
- images/logos/

Main label repo:
- hello-texas-records/Roster Photos/<artist-id>-roster-photo.png
- hello-texas-records/Roster Photos/<artist-id>-hero-photo.png
- hello-texas-records/Roster Photos/<artist-id>-photo-1.png
- hello-texas-records/Roster Photos/<artist-id>-photo-2.png
- hello-texas-records/Roster Photos/<artist-id>-photo-3.png

## What changed

The generator no longer asks for:
- images/artist/<artist-id>-hero.png
- images/artist/<artist-id>-photo-1.png
- images/artist/<artist-id>-photo-2.png
- images/artist/<artist-id>-photo-3.png

It points generated HTML to:
- ../hello-texas-records/Roster Photos/<artist-id>-hero-photo.png
- ../hello-texas-records/Roster Photos/<artist-id>-photo-1.png
- ../hello-texas-records/Roster Photos/<artist-id>-photo-2.png
- ../hello-texas-records/Roster Photos/<artist-id>-photo-3.png

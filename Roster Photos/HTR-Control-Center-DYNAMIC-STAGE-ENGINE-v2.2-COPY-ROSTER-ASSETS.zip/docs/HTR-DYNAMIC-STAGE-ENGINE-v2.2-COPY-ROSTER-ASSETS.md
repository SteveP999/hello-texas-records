# HTR Dynamic Stage Engine v2.2 Copy Roster Assets

This fixes the GitHub Pages asset issue.

## Locked rule

You manage photos here:
D:\hello-texas-records\Roster Photos\

- <artist-id>-roster-photo.png
- <artist-id>-hero-photo.png
- <artist-id>-photo-1.png
- <artist-id>-photo-2.png
- <artist-id>-photo-3.png

Build Artist Site copies them automatically into:
D:\<ArtistRepo>\images\artist\

The generated live site uses:
- images/artist/<artist-id>-hero-photo.png
- images/artist/<artist-id>-photo-1.png
- images/artist/<artist-id>-photo-2.png
- images/artist/<artist-id>-photo-3.png

Why:
GitHub Pages cannot reliably load sibling local repo folders like ../hello-texas-records.
The source stays centralized, but the published artist repo gets the needed copies.

Other changes:
- Larger hero/logo.
- Less dead space.
- Latest single/music stays before video.
- Video moved lower.

import json
import re
import shutil
from pathlib import Path
from urllib.parse import quote

ROOT = Path(r"D:\HTR-Control-Center")
DATA = ROOT / "data"

ARTISTS_FILE = DATA / "artists.json"
SONGS_FILE = DATA / "master-songs.json"
RADIO_FILE = DATA / "radio-data.json"

MAIN_REPO = Path(r"D:\hello-texas-records")
MAIN_RADIO_FILE = MAIN_REPO / "radio-data.json"

EXCLUDE_ARTIST_IDS = {"lucas-harlow", "neon-thunder"}
EXCLUDE_TITLE_PARTS = {"texxxas tales"}

# LOCKED RULE:
# HTR Records homepage radio uses coverImage.
# coverImage must be an absolute URL.
# If master-songs coverImage is already absolute, preserve it exactly.
# Do not convert /covers/ to /images/covers/.
# Do not let albumCover overwrite coverImage.
# albumCover may exist for artist sites, but homepage radio artwork comes from coverImage.

FALLBACK_REPOS = {
    "hello-texas": "Hello-Texas",
    "avery-ivey": "Avery-Ivey",
    "ivey-wilder": "Ivey-Wilder",
    "daniel-kincaid": "Daniel-Kincaid",
    "lucas-harlow": "Lucas-Harlow",
    "night-shift": "Night-Shift",
    "nightstrike": "NightStrike",
    "parsons-cross": "Parsons-Cross",
    "rio-valencia": "Rio-Valencia",
    "sawyer-price": "Sawyer-Price",
    "skyline-theory": "Skyline-Theory",
    "silent-oblivion": "Silent-Oblivion",
    "taylor-martin": "Taylor-Martin",
    "vincent-cole": "Vincent-Cole",
    "borrowed-whispers": "Borrowed-Whispers",
    "brightons": "Brightons",
    "vanta": "vanta",
    "pulse7": "pulse7",
    "stephen-parsons": "stephen-parsons",
}


def read_json(path, default):
    return json.loads(path.read_text(encoding="utf-8-sig")) if path.exists() else default


def write_json(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")


def is_absolute_url(value):
    return bool(re.match(r"^https?://", str(value or ""), flags=re.I))


def clean_path(value):
    return str(value or "").strip().strip('"').strip("'").replace("\\", "/")


def repo_slug_for_song(song, artist_lookup):
    artist_id = (song.get("artistId") or "").strip()
    artist = artist_lookup.get(artist_id, {})

    repo = clean_path(artist.get("githubRepo") or artist.get("repo") or artist.get("repoName") or "")
    if repo:
        return repo.split("/")[-1]

    repo_folder = clean_path(artist.get("repoFolder") or artist.get("repoPath") or "")
    if repo_folder:
        return repo_folder.rstrip("/").split("/")[-1]

    return FALLBACK_REPOS.get(artist_id, artist_id)


def to_raw_github_url(song, artist_lookup, value):
    value = clean_path(value)
    if not value:
        return ""

    if is_absolute_url(value):
        # IMPORTANT: preserve exact existing working URLs.
        return value

    value = value.lstrip("./")
    repo = repo_slug_for_song(song, artist_lookup)
    if not repo:
        return value

    safe_path = "/".join(quote(part) for part in value.split("/"))
    return f"https://raw.githubusercontent.com/SteveP999/{repo}/main/{safe_path}"


def pick_cover_image(song, artist_lookup):
    # HTR homepage radio artwork source of truth.
    # First choice is master-songs coverImage. This was the field that worked before.
    for key in ["coverImage", "cover", "image"]:
        url = to_raw_github_url(song, artist_lookup, song.get(key))
        if url:
            return url

    # Last resort only. Do not prefer albumCover for radio.
    return to_raw_github_url(song, artist_lookup, song.get("albumCover"))


def should_include(song):
    artist_id = (song.get("artistId") or "").strip()
    if artist_id in EXCLUDE_ARTIST_IDS:
        return False

    title = (song.get("title") or "").lower()
    album = (song.get("album") or "").lower()
    if any(x in title or x in album for x in EXCLUDE_TITLE_PARTS):
        return False

    if song.get("includeOnRadio", True) is False:
        return False

    audio = song.get("audioFile") or song.get("audioSrc") or song.get("audio")
    return bool(audio)


def main():
    artists = read_json(ARTISTS_FILE, [])
    artist_lookup = {a.get("id", ""): a for a in artists}

    songs = read_json(SONGS_FILE, [])
    tracks = []

    for song in songs:
        if not should_include(song):
            continue

        audio = song.get("audioFile") or song.get("audioSrc") or song.get("audio") or ""
        cover = pick_cover_image(song, artist_lookup)

        tracks.append({
            "id": song.get("id", ""),
            "artist": song.get("artist", ""),
            "artistId": song.get("artistId", ""),
            "title": song.get("title", ""),
            "album": song.get("album", ""),
            "genre": song.get("genre", ""),
            "coverImage": cover,
            "cover": cover,
            "audioFile": audio,
            "audioSrc": audio,
            "youtubeUrl": song.get("youtubeUrl", ""),
            "videos": song.get("videos", []),
            "explicit": song.get("explicit", False),
            "tags": song.get("tags", []),
        })

    write_json(RADIO_FILE, tracks)
    print(f"Generated: {RADIO_FILE}")
    print(f"Tracks: {len(tracks)}")
    print("LOCKED: coverImage is preserved from master-songs and is never overwritten by albumCover.")

    if MAIN_REPO.exists():
        write_json(MAIN_RADIO_FILE, tracks)
        print(f"Copied: {MAIN_RADIO_FILE}")
    else:
        print(f"Skipped copy. Main repo not found: {MAIN_REPO}")


if __name__ == "__main__":
    main()

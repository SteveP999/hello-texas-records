@echo off
cd /d D:\HTR-Control-Center
py "scripts\build-radio-data.py"
echo.
echo HTR Radio data rebuilt and copied to D:\hello-texas-records\radio-data.json if repo exists.
echo Now run HTR-MENU.bat option 9 to publish HelloTexasRecords.com.
echo.
pause

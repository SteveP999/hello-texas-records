HTR RADIO COVERIMAGE LOCK

This fixes the HelloTexasRecords.com bottom HTR Radio player data.

Replace:
D:\HTR-Control-Center\scripts\build-radio-data.py

Optional helper:
D:\HTR-Control-Center\lock-htr-radio-coverimage.bat

Then run:
1. lock-htr-radio-coverimage.bat
2. HTR-MENU.bat -> 9. Publish HelloTexasRecords.com Repo

LOCKED RULE:
- HTR Radio uses coverImage.
- coverImage must be an absolute URL.
- coverImage comes from master-songs.json coverImage.
- If master-songs.json coverImage is already a full GitHub/Dropbox URL, it is preserved exactly.
- albumCover does NOT overwrite radio coverImage.
- This does NOT touch hellotexasradio.com or FM dial files.

Why this fixes the break:
The broken rebuild changed working coverImage URLs from:
  .../main/covers/...

into:
  .../main/images/covers/...

That broke most existing images because the files were not actually there.
This lock stops the generator from inventing a new path.

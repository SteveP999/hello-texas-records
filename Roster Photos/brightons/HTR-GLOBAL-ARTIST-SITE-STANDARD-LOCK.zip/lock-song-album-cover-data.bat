@echo off
cd /d D:\HTR-Control-Center
py "scripts\lock-song-album-cover-data.py"
echo.
pause

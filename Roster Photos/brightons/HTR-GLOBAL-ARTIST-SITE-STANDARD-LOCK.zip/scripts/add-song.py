import json
import re
import subprocess
import sys
from pathlib import Path

ROOT = Path(r"D:\HTR-Control-Center")
DATA = ROOT / "data"
ARTISTS_FILE = DATA / "artists.json"
SONGS_FILE = DATA / "master-songs.json"


def read_json(path, default):
    if not path.exists():
        return default
    return json.loads(path.read_text(encoding="utf-8-sig"))


def write_json(path, data):
    path.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")


def slugify(text):
    return re.sub(r"[^a-z0-9]+", "-", str(text).lower()).strip("-")


def yes_no(prompt, default=False):
    suffix = "Y/n" if default else "y/N"
    while True:
        value = input(f"{prompt} ({suffix}): ").strip().lower()
        if not value:
            return default
        if value in {"y", "yes"}:
            return True
        if value in {"n", "no"}:
            return False
        print("Please enter Y or N.")


def normalize_cover(value):
    value = (value or "").strip().strip('"').strip("'").replace("\\", "/")
    if not value:
        return ""
    if value.startswith(("http://", "https://")):
        return value.replace("/main/covers/", "/main/images/covers/")
    value = value.lstrip("./")
    if value.startswith("images/covers/"):
        return value
    if value.startswith("covers/"):
        return "images/covers/" + Path(value).name
    return "images/covers/" + Path(value).name

def run_optional(label, command):
    print(f"\n--- {label} ---")
    try:
        result = subprocess.run(command, cwd=str(ROOT), shell=True)
        if result.returncode != 0:
            print(f"WARNING: {label} returned exit code {result.returncode}.")
    except Exception as exc:
        print(f"WARNING: Could not run {label}: {exc}")


def pick_artist(artists):
    print("\nAvailable artists:")
    for idx, artist in enumerate(sorted(artists, key=lambda a: a.get("name", "")), start=1):
        print(f"  {idx:02d}. {artist.get('name','')} [{artist.get('id','')}]")
    print("\nUse the artist ID, not the display name. Example: borrowed-whispers")
    artist_id = input("Artist ID: ").strip().lower()
    artist = next((a for a in artists if a.get("id", "").lower() == artist_id), None)
    if not artist:
        raise SystemExit(f"Artist not found: {artist_id}")
    return artist


print("\n==================================================")
print(" HTR ADD SONG - STANDARD")
print("==================================================")
print("\nBefore continuing, have this ready:")
print("  1. Artist ID")
print("  2. Song title")
print("  3. Album title")
print("  4. Release date, optional")
print("  5. Dropbox MP3 raw=1 link")
print("  6. Song cover filename in images/covers/")
print("  7. Album cover filename in images/covers/, if different")
print("  8. YouTube/video link, optional")
print("  9. Whether this is the latest/featured song")
print(" 10. Whether it should play on HTR Radio")
print("\nThis updates data/master-songs.json and then can rebuild site data.")
print("It does NOT publish unless you run a publish/update option afterward.\n")

if not yes_no("Continue", True):
    raise SystemExit("Cancelled.")

artists = read_json(ARTISTS_FILE, [])
songs = read_json(SONGS_FILE, [])
artist = pick_artist(artists)
artist_id = artist.get("id")
artist_name = artist.get("name", "")
genre_default = artist.get("genre", "")

print(f"\nAdding song for: {artist_name} [{artist_id}]\n")

title = input("Song title: ").strip()
if not title:
    raise SystemExit("Song title is required.")

album = input("Album title: ").strip() or "Singles"
release_date = input("Release date YYYY-MM-DD (optional): ").strip()
release_type = input("Release type (single/album track) [single]: ").strip() or "single"
genre = input(f"Genre [{genre_default}]: ").strip() or genre_default
audio = input("Dropbox MP3 URL/raw link: ").strip()
cover = normalize_cover(input("Song cover filename/path: ").strip())
album_slug = slugify(album)
default_album_cover = f"images/covers/{artist_id}-{album_slug}-ALBUM-cover.png"
album_cover_raw = input(f"Album cover filename/path (Enter = {default_album_cover}): ").strip()
album_cover = normalize_cover(album_cover_raw) if album_cover_raw else default_album_cover
featured = yes_no("Make this the latest/featured song?", True)
include_homepage = yes_no("Include this song on HelloTexasRecords.com latest/homepage?", featured)
include_radio = yes_no("Include this song on HTR Radio?", True)
explicit = yes_no("Explicit?", False)
youtube = input("YouTube/video URL (optional): ").strip()

song_id_base = slugify(f"{artist_id}-{title}")
song_id = song_id_base
counter = 2
existing_ids = {s.get("id") for s in songs}
while song_id in existing_ids:
    song_id = f"{song_id_base}-{counter}"
    counter += 1

videos = [{"title": "Official Video", "youtube": youtube}] if youtube else []

new_song = {
    "id": song_id,
    "artistId": artist_id,
    "artist": artist_name,
    "title": title,
    "album": album,
    "genre": genre,
    "releaseType": release_type,
    "releaseDate": release_date,
    "coverImage": cover,
    "albumCover": album_cover,
    "audioFile": audio,
    "youtubeUrl": youtube,
    "videos": videos,
    "featured": featured,
    "explicit": explicit,
    "includeOnRadio": include_radio,
    "includeOnHomepage": include_homepage,
    "tags": []
}

print("\nSong to add:")
print(json.dumps(new_song, indent=2, ensure_ascii=False))
print()
if not yes_no("Save this song", True):
    raise SystemExit("Cancelled before save.")

songs.append(new_song)
if featured:
    for s in songs:
        if s.get("artistId") == artist_id and s.get("id") != song_id:
            s["featured"] = False
    artist["latestTitle"] = title

write_json(SONGS_FILE, songs)
write_json(ARTISTS_FILE, artists)
print("\nSaved:")
print(f"  {SONGS_FILE}")
print(f"  {ARTISTS_FILE}")

print("\nRecommended next steps:")
print("  1. Rebuild this artist site")
print("  2. Rebuild homepage data")
print("  3. Rebuild radio data")
print("  4. Inspect files BEFORE publishing")

if yes_no("Run homepage/radio data rebuild now?", False):
    print(f"\nFirst use menu option 3 to rebuild artist site, then enter: {artist_id}")
    if yes_no("Run homepage data rebuild now?", True):
        if (ROOT / "build-homepage-data.bat").exists():
            run_optional("Rebuild Homepage Data", "build-homepage-data.bat")
        else:
            run_optional("Rebuild Homepage Data", "python scripts\\build-homepage-data.py")
    if yes_no("Run radio data rebuild now?", True):
        if (ROOT / "build-radio-data.bat").exists():
            run_optional("Rebuild Radio Data", "build-radio-data.bat")
        else:
            run_optional("Rebuild Radio Data", "python scripts\\build-radio-data.py")

print("\nAdd Song complete. Inspect before publishing.")

import json
from collections import Counter
from pathlib import Path
import re

ROOT = Path(r"D:\HTR-Control-Center")
DATA = ROOT / "data"

songs = json.loads((DATA / "master-songs.json").read_text(encoding="utf-8"))

def slugify(text):
    return re.sub(r"[^a-z0-9]+", "-", str(text or "").lower()).strip("-")

def expected_album_cover(song):
    artist_id = (song.get("artistId") or "").strip()
    album = (song.get("album") or "").strip()
    if not artist_id or not album or album.lower() == "singles":
        return ""
    return f"images/covers/{artist_id}-{slugify(album)}-ALBUM-cover.png"

print("===================================")
print(" MASTER SONG VALIDATION")
print("===================================")
print()

print(f"Total Songs: {len(songs)}")

# Duplicate IDs
ids = [s["id"] for s in songs]
duplicates = [item for item, count in Counter(ids).items() if count > 1]

print()
print(f"Duplicate IDs: {len(duplicates)}")

for dup in duplicates:
    print(f"  DUPLICATE: {dup}")

# Missing titles
missing_titles = [s for s in songs if not s.get("title")]

print()
print(f"Missing Titles: {len(missing_titles)}")

# Missing covers
missing_covers = [s for s in songs if not s.get("coverImage")]

print()
print(f"Missing Covers: {len(missing_covers)}")

# Missing audio
missing_audio = [s for s in songs if not s.get("audioFile")]

print()
print(f"Missing Audio Files: {len(missing_audio)}")


# Album cover rule validation
album_cover_issues = []
for s in songs:
    expected = expected_album_cover(s)
    if not expected:
        continue
    actual = (s.get("albumCover") or "").strip().replace("\\", "/")
    cover = (s.get("coverImage") or s.get("cover") or s.get("image") or "").strip().replace("\\", "/")
    if not actual:
        album_cover_issues.append((s, "missing albumCover", actual, expected))
    elif cover and actual == cover:
        album_cover_issues.append((s, "albumCover matches song cover", actual, expected))
    elif not actual.lower().endswith("-album-cover.png"):
        album_cover_issues.append((s, "albumCover does not follow -ALBUM-cover.png standard", actual, expected))

print()
print(f"Album Cover Rule Issues: {len(album_cover_issues)}")
for s, reason, actual, expected in album_cover_issues[:100]:
    print(f"  {s.get('artist','')} - {s.get('title','')} | {reason}")
    print(f"    actual:   {actual}")
    print(f"    expected: {expected}")
if len(album_cover_issues) > 100:
    print(f"  ...and {len(album_cover_issues) - 100} more")

# Artist breakdown
print()
print("Songs Per Artist:")
artist_counts = Counter([s["artist"] for s in songs])

for artist, count in sorted(artist_counts.items()):
    print(f"  {artist}: {count}")

print()
print("===================================")
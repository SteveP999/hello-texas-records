import json
import re
from pathlib import Path

ROOT = Path(r"D:\HTR-Control-Center")
DATA = ROOT / "data"
ARTISTS_FILE = DATA / "artists.json"
SONGS_FILE = DATA / "master-songs.json"

def slugify(text):
    text = str(text or "").lower()
    text = text.replace("&", "and")
    text = text.replace("'", "").replace("’", "").replace("‘", "")
    text = re.sub(r"[^a-z0-9]+", "-", text)
    return text.strip("-")

def read_json(path, default):
    if path.exists():
        return json.loads(path.read_text(encoding="utf-8-sig"))
    return default

def write_json(path, data):
    path.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")

def normalize_cover(value):
    value = (value or "").strip().strip('"').strip("'").replace("\\", "/")
    if not value:
        return ""
    if value.startswith(("http://", "https://")):
        return value.replace("/main/covers/", "/main/images/covers/")
    value = value.lstrip("./")
    if value.startswith("images/covers/"):
        return value
    if value.startswith("covers/"):
        return "images/covers/" + Path(value).name
    return "images/covers/" + Path(value).name

def expected_album_cover(song):
    artist_id = (song.get("artistId") or "").strip()
    album = (song.get("album") or "").strip()
    if not artist_id or not album or album.lower() == "singles":
        return ""
    return f"images/covers/{artist_id}-{slugify(album)}-ALBUM-cover.png"

def repair_song(song):
    changed = False
    for key in ["coverImage", "cover", "image", "albumCover"]:
        if key in song and isinstance(song[key], str):
            n = normalize_cover(song[key])
            if n != song[key]:
                song[key] = n
                changed = True
    exp = expected_album_cover(song)
    if exp:
        actual = (song.get("albumCover") or "").strip().replace("\\", "/")
        cover = (song.get("coverImage") or song.get("cover") or song.get("image") or "").strip().replace("\\", "/")
        if not actual or actual == cover or not actual.lower().endswith("-album-cover.png"):
            song["albumCover"] = exp
            changed = True
    if "videos" not in song:
        song["videos"] = []
        changed = True
    return changed

def main():
    print("==================================================")
    print("HTR LOCK SONG / ALBUM COVER DATA")
    print("==================================================")
    songs = read_json(SONGS_FILE, [])
    changed_master = 0
    for song in songs:
        if repair_song(song):
            changed_master += 1
    write_json(SONGS_FILE, songs)
    print(f"master-songs.json repaired songs: {changed_master}")
    artists = read_json(ARTISTS_FILE, [])
    changed_files = 0
    for artist in artists:
        repo = Path(artist.get("repoFolder") or artist.get("repoPath") or "")
        if not repo.exists():
            continue
        sp = repo / "songs.json"
        if not sp.exists():
            continue
        local_songs = read_json(sp, [])
        changed = 0
        for song in local_songs:
            if repair_song(song):
                changed += 1
        if changed:
            write_json(sp, local_songs)
            changed_files += 1
            print(f"  {sp}: {changed} songs repaired")
    print(f"artist songs.json files repaired: {changed_files}")
    print("Done. Now rebuild artists with HTR-MENU #4.")

if __name__ == "__main__":
    main()

import json
import re
import shutil
import subprocess
from pathlib import Path
from urllib.parse import urlparse, parse_qsl, urlencode, urlunparse

ROOT = Path(r"D:\HTR-Control-Center")
DATA = ROOT / "data"
ARTISTS_FILE = DATA / "artists.json"
SONGS_FILE = DATA / "master-songs.json"

IMAGE_EXTS = {".png", ".jpg", ".jpeg", ".webp"}
AUDIO_EXTS = {".mp3"}
REQUIRED_COVER_SUFFIX = "-cover"

def slugify(text):
    text = str(text or "").lower()
    text = text.replace("&", "and")
    text = text.replace("'", "").replace("’", "").replace("‘", "")
    text = re.sub(r"[^a-z0-9]+", "-", text)
    return text.strip("-")

def load_json(path, fallback):
    if not path.exists():
        return fallback
    return json.loads(path.read_text(encoding="utf-8-sig"))

def save_json(path, data):
    path.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")

def yes_no(prompt, default=False):
    suffix = "Y/n" if default else "y/N"
    value = input(f"{prompt} ({suffix}): ").strip().lower()
    if not value:
        return default
    return value in {"y", "yes"}

def normalize_dropbox_link(url):
    url = (url or "").strip()
    if not url:
        return ""
    if "dropbox.com" not in url.lower():
        return url

    parsed = urlparse(url)
    query = dict(parse_qsl(parsed.query, keep_blank_values=True))
    query.pop("dl", None)
    query["raw"] = "1"
    return urlunparse((parsed.scheme, parsed.netloc, parsed.path, parsed.params, urlencode(query), parsed.fragment))

def choose_from_list(items, label):
    print()
    print(label)
    for i, item in enumerate(items, 1):
        print(f"  {i}. {item}")
    while True:
        raw = input("Choose number: ").strip()
        if raw.isdigit() and 1 <= int(raw) <= len(items):
            return items[int(raw) - 1]
        print("Enter a valid number.")

def title_case_from_slug(slug):
    small = {"a","an","and","as","at","but","by","for","from","in","into","of","on","or","the","to","with"}
    words = [w for w in re.split(r"[-_ ]+", slug) if w]
    out = []
    for i, w in enumerate(words):
        if i and w.lower() in small:
            out.append(w.lower())
        else:
            out.append(w[:1].upper() + w[1:])
    return " ".join(out)

def clean_song_title_from_folder(folder_name, artist_name):
    name = folder_name.strip()
    # Examples:
    # Ivey Wilder - 01 - Main Character
    # Borrowed Whispers - 01 - Still Falling For You
    pattern = rf"^{re.escape(artist_name)}\s*-\s*(\d{{1,2}})\s*-\s*(.+)$"
    m = re.match(pattern, name, flags=re.I)
    if m:
        return int(m.group(1)), m.group(2).strip()

    m = re.match(r"^(\d{1,2})\s*[-_]\s*(.+)$", name)
    if m:
        return int(m.group(1)), m.group(2).strip()

    m = re.search(r"(\d{1,2})", name)
    track = int(m.group(1)) if m else 999
    return track, name

def find_album_cover(album_folder, artist_id, album_title):
    images = [p for p in album_folder.iterdir() if p.is_file() and p.suffix.lower() in IMAGE_EXTS]
    if not images:
        return None

    album_slug = slugify(album_title)
    preferred = []
    for p in images:
        s = slugify(p.stem)
        if "album-cover" in s or "-album-" in s or s.endswith("-album-cover") or album_slug in s:
            preferred.append(p)

    if len(preferred) == 1:
        return preferred[0]
    if preferred:
        return choose_from_list(preferred, "Choose album cover:")
    return choose_from_list(images, "Choose album cover:")

def find_song_cover(song_folder, artist_id, song_title):
    images = [p for p in song_folder.iterdir() if p.is_file() and p.suffix.lower() in IMAGE_EXTS]
    if not images:
        return None

    song_slug = slugify(song_title)
    preferred = []
    for p in images:
        s = slugify(p.stem)
        # Website cover should be the 1x1 cover. Avoid alternate aspect ratio covers if possible.
        if song_slug in s and "cover" in s and "9x16" not in s and "16x9" not in s:
            preferred.append(p)

    if len(preferred) == 1:
        return preferred[0]
    if preferred:
        return choose_from_list(preferred, f"Choose website cover for {song_title}:")
    return choose_from_list(images, f"Choose website cover for {song_title}:")

def find_mp3(song_folder):
    mp3s = sorted([p for p in song_folder.iterdir() if p.is_file() and p.suffix.lower() == ".mp3"])
    if not mp3s:
        return None
    if len(mp3s) == 1:
        return mp3s[0]
    return choose_from_list(mp3s, f"Choose website MP3 in {song_folder.name}:")

def upsert_song(songs, new_song):
    for idx, song in enumerate(songs):
        if song.get("id") == new_song["id"]:
            old = song.copy()
            old.update(new_song)
            songs[idx] = old
            return "updated"
    songs.append(new_song)
    return "added"

def copy_if_needed(src, dest):
    dest.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(src, dest)

def main():
    print()
    print("==================================================")
    print(" HTR ADD ALBUM FROM FOLDER v2.0")
    print("==================================================")
    print("Reads your clean Music album folder, copies website covers,")
    print("normalizes Dropbox links to raw=1, and updates master-songs.json.")
    print()

    artists = load_json(ARTISTS_FILE, [])
    songs = load_json(SONGS_FILE, [])

    active_artists = [a for a in artists if a.get("id") and a.get("name")]
    print("Artists:")
    for i, a in enumerate(active_artists, 1):
        print(f"  {i}. {a.get('id')}  ({a.get('name')})")

    raw_artist = input("\nArtist ID or number: ").strip()
    if raw_artist.isdigit() and 1 <= int(raw_artist) <= len(active_artists):
        artist = active_artists[int(raw_artist) - 1]
    else:
        artist = next((a for a in active_artists if a.get("id") == raw_artist), None)

    if not artist:
        print("ERROR: Artist not found.")
        return

    artist_id = artist["id"]
    artist_name = artist.get("name", artist_id)
    genre = artist.get("genre", "")
    repo_folder = Path(artist.get("repoFolder") or artist.get("repoPath") or f"D:\\{artist_id}")

    album_title = input("Album title: ").strip()
    if not album_title:
        print("ERROR: Album title is required.")
        return

    album_type = input("Album badge/type (Enter = Album): ").strip() or "Album"
    release_date = input("Release date YYYY-MM-DD (blank ok): ").strip()

    folder_raw = input("Album folder path from C or D drive: ").strip().strip('"')
    album_folder = Path(folder_raw)

    if not album_folder.exists():
        print(f"ERROR: Folder not found: {album_folder}")
        return

    album_cover = find_album_cover(album_folder, artist_id, album_title)
    if not album_cover:
        print("ERROR: No album cover found in album folder root.")
        return

    song_folders = [p for p in album_folder.iterdir() if p.is_dir()]
    song_folders = sorted(song_folders, key=lambda p: clean_song_title_from_folder(p.name, artist_name)[0])

    if not song_folders:
        print("ERROR: No song folders found inside album folder.")
        return

    print()
    print("Detected album order:")
    detected = []
    for p in song_folders:
        track, title = clean_song_title_from_folder(p.name, artist_name)
        detected.append((track, title, p))
        print(f"  {track:02d}. {title}  [{p.name}]")

    if not yes_no("Use this detected order?", True):
        print("Rename folders with track numbers first, then rerun. This avoids manual order mistakes.")
        return

    dest_covers = repo_folder / "images" / "covers"
    dest_covers.mkdir(parents=True, exist_ok=True)

    album_cover_dest_name = f"{artist_id}-{slugify(album_title)}-ALBUM-cover{album_cover.suffix.lower()}"
    copy_if_needed(album_cover, dest_covers / album_cover_dest_name)
    album_cover_rel = f"images/covers/{album_cover_dest_name}"

    print()
    print("Dropbox links:")
    print("- Paste the Dropbox MP3 shared link for each song.")
    print("- The tool converts dl=0 to raw=1 automatically.")
    print("- Blank is allowed, but that song will not be included in radio yet.")
    print()

    added = updated = missing_mp3 = missing_cover = 0
    latest_chosen = False

    for track_number, title, folder in detected:
        print("--------------------------------------------------")
        print(f"{track_number:02d}. {title}")
        mp3 = find_mp3(folder)
        cover = find_song_cover(folder, artist_id, title)

        if not mp3:
            print("WARNING: No MP3 found.")
            missing_mp3 += 1
        else:
            print(f"MP3 found: {mp3.name}")

        if not cover:
            print("WARNING: No website cover found.")
            missing_cover += 1
            cover_rel = ""
        else:
            song_cover_dest_name = f"{artist_id}-{slugify(title)}-cover{cover.suffix.lower()}"
            copy_if_needed(cover, dest_covers / song_cover_dest_name)
            cover_rel = f"images/covers/{song_cover_dest_name}"
            print(f"Cover copied: {song_cover_dest_name}")

        audio_link = input("MP3 Dropbox link: ").strip()
        audio_link = normalize_dropbox_link(audio_link)

        default_latest = not latest_chosen and track_number == 1
        is_latest = yes_no("Mark as latest/featured?", default_latest)
        if is_latest:
            latest_chosen = True
            # Ensure only one latest for this artist.
            for s in songs:
                if s.get("artistId") == artist_id:
                    s["isLatest"] = False
                    s["featured"] = False
                    s["includeOnHomepage"] = False

        song_id = f"{artist_id}-{slugify(title)}"

        status = upsert_song(songs, {
            "id": song_id,
            "artistId": artist_id,
            "artist": artist_name,
            "title": title,
            "album": album_title,
            "albumType": album_type,
            "albumOrder": track_number,
            "trackNumber": track_number,
            "genre": genre,
            "releaseType": "album-track",
            "releaseDate": release_date,
            "coverImage": cover_rel,
            "albumCover": album_cover_rel,
            "audioFile": audio_link,
            "youtubeUrl": "",
            "videos": [],
            "featured": is_latest,
            "isLatest": is_latest,
            "explicit": False,
            "includeOnRadio": bool(audio_link),
            "includeOnHomepage": is_latest,
            "tags": []
        })

        if status == "added":
            added += 1
        else:
            updated += 1

    # Update artist latest title if one was chosen.
    latest = next((s for s in songs if s.get("artistId") == artist_id and s.get("isLatest")), None)
    if latest:
        artist["latestTitle"] = latest.get("title", "")

    save_json(SONGS_FILE, songs)
    save_json(ARTISTS_FILE, artists)

    print()
    print("==================================================")
    print("ALBUM IMPORT COMPLETE")
    print("==================================================")
    print(f"Artist: {artist_name}")
    print(f"Album: {album_title}")
    print(f"Added: {added}")
    print(f"Updated: {updated}")
    print(f"Missing MP3 files: {missing_mp3}")
    print(f"Missing website covers: {missing_cover}")
    print(f"Covers copied to: {dest_covers}")
    print()

    if yes_no("Build artist site now?", True):
        build = ROOT / "scripts" / "build-artist-site.py"
        if build.exists():
            subprocess.run(["python", str(build)], cwd=str(ROOT))
        else:
            print("Missing build script.")

if __name__ == "__main__":
    main()

HTR GLOBAL ARTIST SITE STANDARD LOCK

Replace these in D:\HTR-Control-Center:
- scripts\build-artist-site.py
- scripts\create-artist.py
- scripts\add-song.py
- scripts\add-album-from-folder.py
- scripts\validate-master-songs.py
- lock-song-album-cover-data.bat
- scripts\lock-song-album-cover-data.py

Then run once:
- lock-song-album-cover-data.bat

Then rebuild any artist with:
- HTR-MENU.bat -> #4

After replacing files:
1. Run lock-song-album-cover-data.bat once.
2. Rebuild Brightons with HTR-MENU #4.

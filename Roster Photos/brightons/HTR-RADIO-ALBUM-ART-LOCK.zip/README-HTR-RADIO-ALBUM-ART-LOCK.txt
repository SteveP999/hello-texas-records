HTR Records Homepage Radio Album Art Lock

This fixes ONLY the HelloTexasRecords.com bottom/random HTR Radio player.

Replace:
D:\hello-texas-records\homepage-app.js
D:\HTR-Control-Center\scripts\build-radio-data.py

Then run:
HTR-MENU.bat -> Rebuild Radio Data
HTR-MENU.bat -> Publish HelloTexasRecords.com Repo

Locked rule:
- HTR Records homepage radio displays album art first.
- Song art is fallback only.
- It tries both /images/covers/ and /covers/.
- This does not touch hellotexasradio.com or FM dial files.

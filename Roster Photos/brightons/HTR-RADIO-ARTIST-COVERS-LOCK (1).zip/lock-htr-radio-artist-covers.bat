@echo off
cd /d D:\HTR-Control-Center
py "scripts\build-radio-data.py"
echo.
echo Now run HTR-MENU.bat option 9 to publish HelloTexasRecords.com.
echo.
pause

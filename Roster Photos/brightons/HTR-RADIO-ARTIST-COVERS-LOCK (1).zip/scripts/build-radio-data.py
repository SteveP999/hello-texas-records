import json
import re
from pathlib import Path
from urllib.parse import quote

ROOT = Path(r"D:\HTR-Control-Center")
DATA = ROOT / "data"
MAIN_REPO = Path(r"D:\hello-texas-records")

ARTISTS_FILE = DATA / "artists.json"
SONGS_FILE = DATA / "master-songs.json"
CONTROL_RADIO_FILE = DATA / "radio-data.json"
MAIN_RADIO_FILE = MAIN_REPO / "radio-data.json"

EXCLUDE_ARTIST_IDS = {"lucas-harlow", "neon-thunder"}
EXCLUDE_TITLE_PARTS = {"texxxas tales"}

FALLBACK_REPOS = {
    "hello-texas": "Hello-Texas",
    "avery-ivey": "Avery-Ivey",
    "ivey-wilder": "Ivey-Wilder",
    "daniel-kincaid": "Daniel-Kincaid",
    "lucas-harlow": "Lucas-Harlow",
    "night-shift": "Night-Shift",
    "nightstrike": "NightStrike",
    "parsons-cross": "Parsons-Cross",
    "rio-valencia": "Rio-Valencia",
    "sawyer-price": "Sawyer-Price",
    "skyline-theory": "Skyline-Theory",
    "silent-oblivion": "Silent-Oblivion",
    "taylor-martin": "Taylor-Martin",
    "vincent-cole": "Vincent-Cole",
    "borrowed-whispers": "Borrowed-Whispers",
    "brightons": "Brightons",
    "vanta": "vanta",
    "pulse7": "PULSE7",
    "stephen-parsons": "stephen-parsons",
}


def read_json(path, default):
    return json.loads(path.read_text(encoding="utf-8-sig")) if path.exists() else default


def write_json(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")


def slugify(text):
    text = str(text or "").lower()
    text = text.replace("&", "and")
    text = text.replace("'", "").replace("’", "").replace("‘", "")
    text = re.sub(r"[^a-z0-9]+", "-", text)
    return text.strip("-")


def clean(value):
    return str(value or "").strip().strip('"').strip("'").replace("\\", "/")


def repo_slug_for_song(song, artist_lookup):
    artist_id = (song.get("artistId") or "").strip()
    artist = artist_lookup.get(artist_id, {})

    repo = clean(artist.get("githubRepo") or artist.get("repo") or artist.get("repoName") or "")
    if repo:
        return repo.split("/")[-1]

    repo_folder = clean(artist.get("repoFolder") or artist.get("repoPath") or "")
    if repo_folder:
        return repo_folder.rstrip("/").split("/")[-1]

    return FALLBACK_REPOS.get(artist_id, artist_id)


def artist_repo_folder(song, artist_lookup):
    artist_id = (song.get("artistId") or "").strip()
    artist = artist_lookup.get(artist_id, {})

    for key in ["repoFolder", "repoPath"]:
        value = artist.get(key)
        if value:
            p = Path(str(value))
            if p.exists():
                return p

    repo_slug = repo_slug_for_song(song, artist_lookup)
    candidates = [
        Path("D:/") / repo_slug,
        Path("D:/") / artist_id,
        Path("D:/") / slugify(song.get("artist") or artist_id),
    ]

    for p in candidates:
        if p.exists():
            return p

    return Path("D:/") / repo_slug


def find_cover_filename(song, artist_lookup):
    artist_id = (song.get("artistId") or "").strip()
    title_slug = slugify(song.get("title") or "")
    covers = artist_repo_folder(song, artist_lookup) / "images" / "covers"

    expected_stems = [
        f"{artist_id}-{title_slug}-cover",
    ]

    # Keep old explicitly named data if it already points to the correct standard folder.
    for key in ["coverImage", "cover", "image"]:
        raw = clean(song.get(key))
        if raw.startswith("images/covers/"):
            expected_stems.insert(0, Path(raw).stem)

    if covers.exists():
        all_files = [p for p in covers.iterdir() if p.is_file() and p.suffix.lower() in [".png", ".jpg", ".jpeg", ".webp"]]

        for stem in expected_stems:
            for p in all_files:
                if p.stem.lower() == stem.lower():
                    return p.name

        # Soft fallback: title slug must appear, but do not invent Radio Covers or album-cover names.
        for p in all_files:
            name = p.stem.lower()
            if name.startswith(f"{artist_id}-") and title_slug and title_slug in name and name.endswith("-cover"):
                return p.name

    return f"{artist_id}-{title_slug}-cover.png"


def raw_github_cover(song, artist_lookup):
    repo = repo_slug_for_song(song, artist_lookup)
    filename = find_cover_filename(song, artist_lookup)
    safe_filename = quote(filename)
    return f"https://raw.githubusercontent.com/SteveP999/{repo}/main/images/covers/{safe_filename}"


def should_include(song):
    artist_id = (song.get("artistId") or "").strip()
    if artist_id in EXCLUDE_ARTIST_IDS:
        return False

    title = (song.get("title") or "").lower()
    album = (song.get("album") or "").lower()
    if any(x in title or x in album for x in EXCLUDE_TITLE_PARTS):
        return False

    if song.get("includeOnRadio", True) is False:
        return False

    return bool(song.get("audioFile") or song.get("audioSrc") or song.get("audio"))


def main():
    artists = read_json(ARTISTS_FILE, [])
    artist_lookup = {a.get("id", ""): a for a in artists}

    tracks = []
    for song in read_json(SONGS_FILE, []):
        if not should_include(song):
            continue

        audio = song.get("audioFile") or song.get("audioSrc") or song.get("audio") or ""
        cover = raw_github_cover(song, artist_lookup)

        tracks.append({
            "id": song.get("id", ""),
            "artist": song.get("artist", ""),
            "artistId": song.get("artistId", ""),
            "title": song.get("title", ""),
            "album": song.get("album", ""),
            "genre": song.get("genre", ""),
            "coverImage": cover,
            "cover": cover,
            "audioFile": audio,
            "audioSrc": audio,
            "youtubeUrl": song.get("youtubeUrl", ""),
            "videos": song.get("videos", []),
            "explicit": song.get("explicit", False),
            "tags": song.get("tags", []),
        })

    write_json(CONTROL_RADIO_FILE, tracks)
    if MAIN_REPO.exists():
        write_json(MAIN_RADIO_FILE, tracks)

    print("HTR RADIO ARTIST COVER LOCK COMPLETE")
    print(f"Tracks written: {len(tracks)}")
    print("LOCKED: coverImage points to <artist repo>/images/covers/<artist-id>-<song-name>-cover.ext")
    print("LOCKED: No Radio Covers folder. No Roster Photos. No /covers/ fallback.")


if __name__ == "__main__":
    main()

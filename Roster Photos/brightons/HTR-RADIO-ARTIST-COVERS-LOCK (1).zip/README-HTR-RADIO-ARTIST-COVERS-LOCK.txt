HTR RADIO ARTIST COVERS LOCK

This fixes the HelloTexasRecords.com bottom HTR Radio cover art.

Replace:
D:\HTR-Control-Center\scripts\build-radio-data.py
D:\hello-texas-records\homepage-app.js

Copy:
lock-htr-radio-artist-covers.bat
to:
D:\HTR-Control-Center\lock-htr-radio-artist-covers.bat

Run:
lock-htr-radio-artist-covers.bat

Then:
HTR-MENU.bat -> 9. Publish HelloTexasRecords.com Repo

LOCKED RULE:
- Song covers live in the artist repo:
  <artist repo>/images/covers/<artist-id>-<song-name>-cover.png
- HTR Radio coverImage points to that file as a raw GitHub URL.
- No Radio Covers folder.
- No Roster Photos.
- No /radio/covers.
- No albumCover overriding coverImage.

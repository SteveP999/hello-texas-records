HTR Records Homepage Radio Image Fallback Fix

This fixes ONLY the HelloTexasRecords.com bottom/random HTR Radio player.

Replace:
D:\hello-texas-records\homepage-app.js
D:\HTR-Control-Center\scripts\build-radio-data.py

Then run:
HTR-MENU.bat -> Rebuild Radio Data
HTR-MENU.bat -> Publish HelloTexasRecords.com Repo

What this fixes:
- Some existing radio-data coverImage URLs point to /covers/.
- Some newer artist sites use /images/covers/.
- This homepage player now tries both paths automatically.
- It also tries coverImage, cover, image, albumCover, and albumArt.
- It sets fallback handling on the actual <img> tags, so one broken path no longer kills the art.
- This does not touch hellotexasradio.com or the FM dial system.

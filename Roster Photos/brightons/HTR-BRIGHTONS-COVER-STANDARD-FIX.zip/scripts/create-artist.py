import json
from pathlib import Path
import shutil
import re

ROOT = Path(r"D:\HTR-Control-Center")
DATA = ROOT / "data"

ARTISTS_FILE = DATA / "artists.json"
SONGS_FILE = DATA / "master-songs.json"

LABEL_REPO = Path(r"D:\hello-texas-records")
ROSTER_PHOTOS = LABEL_REPO / "Roster Photos"

# ─────────────────────────────────────────────
# LOCKED ASSET RULES
# ─────────────────────────────────────────────
# Source of truth for artist identity/generic photos:
#   D:\hello-texas-records\Roster Photos\<artist-id>\
#
# Required / recommended filenames:
#   <artist-id>-roster-photo.png
#   <artist-id>-hero-photo.png
#   <artist-id>-discography-bg.png
#   <artist-id>-video-bg.png
#   <artist-id>-photo-1.png
#   <artist-id>-photo-2.png
#   <artist-id>-photo-3.png
#
# Artist repos still contain covers/logos/audio data.
# Build Artist Site copies centralized photos into the artist repo for GitHub Pages.

def slugify(text):
    text = str(text or "").lower()
    text = text.replace("'", "").replace("’", "").replace("‘", "")
    text = re.sub(r"[^a-z0-9]+", "-", text)
    return text.strip("-")

def yes_no(prompt):
    while True:
        value = input(prompt).strip().lower()
        if value in ["y", "yes"]:
            return True
        if value in ["n", "no"]:
            return False
        print("Please enter Y or N")

def load_json(path, fallback):
    if not path.exists():
        return fallback
    return json.loads(path.read_text(encoding="utf-8"))

def save_json(path, data):
    path.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")

def normalize_cover(value):
    value = (value or "").strip().strip('"').strip("'").replace("\\", "/")
    if not value:
        return ""
    if value.startswith(("http://", "https://")):
        return value.replace("/main/covers/", "/main/images/covers/")
    value = value.lstrip("./")
    if value.startswith("images/covers/"):
        return value
    if value.startswith("covers/"):
        return "images/covers/" + Path(value).name
    return "images/covers/" + Path(value).name


def roster_asset_rel(artist_id, suffix):
    return f"Roster Photos/{artist_id}/{artist_id}-{suffix}.png"

def roster_asset_abs(artist_id, suffix):
    return ROSTER_PHOTOS / artist_id / f"{artist_id}-{suffix}.png"

def print_asset_check(artist_id):
    print()
    print("Asset intake check:")
    checks = [
        ("roster photo", "roster-photo"),
        ("hero photo", "hero-photo"),
        ("discography bg", "discography-bg"),
        ("video bg", "video-bg"),
        ("photo 1", "photo-1"),
        ("photo 2", "photo-2"),
        ("photo 3", "photo-3"),
    ]
    for label, suffix in checks:
        path = roster_asset_abs(artist_id, suffix)
        if path.exists():
            print(f"  OK: {label}: {path}")
        else:
            print(f"  MISSING: {label}: {path}")

def upsert_by_id(items, new_item):
    item_id = new_item.get("id")
    for idx, item in enumerate(items):
        if item.get("id") == item_id:
            items[idx] = {**item, **new_item}
            return items
    items.append(new_item)
    return items

def rebuild_homepage_data(artists, songs):
    latest_releases = sorted(
        [s for s in songs if s.get("includeOnHomepage", False)],
        key=lambda s: s.get("releaseDate", ""),
        reverse=True
    )[:12]

    featured_artists = [
        a for a in artists
        if a.get("includeOnLabelHome", False)
        and a.get("id") != "neon-thunder"
    ]

    return {
        "latestReleases": latest_releases,
        "featuredArtists": featured_artists
    }

def rebuild_radio_data(songs):
    radio_tracks = []
    for song in songs:
        if not song.get("includeOnRadio", True):
            continue
        if not (song.get("audioFile") or song.get("audioSrc") or song.get("audio")):
            continue
        radio_tracks.append(song)
    return radio_tracks

# ─────────────────────────────────────────────
# LOAD FILES
# ─────────────────────────────────────────────

artists = load_json(ARTISTS_FILE, [])
songs = load_json(SONGS_FILE, [])

# ─────────────────────────────────────────────
# ARTIST INFO
# ─────────────────────────────────────────────

print()
print("===================================")
print(" HELLO TEXAS RECORDS")
print(" CREATE ARTIST")
print("===================================")
print()

artist_name = input("Artist Name: ").strip()
artist_id = slugify(artist_name)

genre = input("Genre: ").strip()
github_repo = input("GitHub Repo (SteveP999/repo-name): ").strip()
site_url = input("Site URL: ").strip()

if not site_url:
    repo_slug = github_repo.split("/")[-1] if "/" in github_repo else artist_id
    site_url = f"https://stevep999.github.io/{repo_slug}/"

include_home = yes_no("Include on Homepage? (Y/N): ")
include_radio = yes_no("Include on Radio? (Y/N): ")

repo_name = github_repo.split("/")[-1] if "/" in github_repo else artist_id
repo_path = f"D:\\{repo_name}"

print_asset_check(artist_id)

# This is the locked homepage roster rule.
roster_photo = roster_asset_rel(artist_id, "roster-photo")

new_artist = {
    "id": artist_id,
    "name": artist_name,
    "repoFolder": repo_path,
    "repoPath": repo_path,
    "githubRepo": github_repo,
    "siteUrl": site_url,
    "genre": genre,
    "status": "active",
    "active": True,
    "logo": "",
    "heroImage": roster_photo,
    "dataFiles": {
        "songs": True,
        "radio": True,
        "latest": True
    },
    "includeOnLabelHome": include_home,
    "includeOnRadio": include_radio,
    "imageCandidates": [
        roster_photo,
        "htr-logo.png"
    ],
    "latestTitle": ""
}

artists = upsert_by_id(artists, new_artist)

# ─────────────────────────────────────────────
# SONGS
# ─────────────────────────────────────────────

print()
song_count = int(input("How many songs? "))

first_title = ""

for i in range(song_count):
    print()
    print(f"Song #{i + 1}")

    title = input("Song Title: ").strip()
    if not first_title:
        first_title = title

    album = input("Album: ").strip()
    release_date = input("Release Date (YYYY-MM-DD): ").strip()
    audio = input("Dropbox MP3 URL: ").strip()
    default_cover = f"images/covers/{artist_id}-{slugify(title)}-cover.png"
    default_album_cover = f"images/covers/{artist_id}-{slugify(album)}-ALBUM-cover.png" if album and album.lower() != "singles" else ""
    cover_raw = input(f"Cover Image Filename or URL (Enter = {default_cover}): ").strip()
    cover = normalize_cover(cover_raw) if cover_raw else default_cover
    album_cover = default_album_cover

    featured = yes_no("Featured Song? (Y/N): ")
    explicit = yes_no("Explicit? (Y/N): ")

    song_id = f"{artist_id}-{slugify(title)}"

    songs = upsert_by_id(songs, {
        "id": song_id,
        "artistId": artist_id,
        "artist": artist_name,
        "title": title,
        "album": album,
        "genre": genre,
        "releaseType": "single",
        "releaseDate": release_date,
        "coverImage": cover,
        "albumCover": album_cover,
        "audioFile": audio,
        "youtubeUrl": "",
        "videos": [],
        "featured": featured,
        "explicit": explicit,
        "includeOnRadio": include_radio,
        "includeOnHomepage": featured,
        "tags": []
    })

# Update latestTitle after songs are entered.
if first_title:
    for artist in artists:
        if artist.get("id") == artist_id:
            artist["latestTitle"] = first_title
            break

# ─────────────────────────────────────────────
# SAVE FILES
# ─────────────────────────────────────────────

save_json(ARTISTS_FILE, artists)
save_json(SONGS_FILE, songs)

print()
print("artists.json updated")
print("master-songs.json updated")

# ─────────────────────────────────────────────
# REBUILD HOMEPAGE/RADIO
# ─────────────────────────────────────────────

homepage_data = rebuild_homepage_data(artists, songs)
homepage_output = DATA / "homepage-data.json"
save_json(homepage_output, homepage_data)
print("homepage-data.json rebuilt")

radio_data = rebuild_radio_data(songs)
radio_output = DATA / "radio-data.json"
save_json(radio_output, radio_data)
print("radio-data.json rebuilt")

# ─────────────────────────────────────────────
# PUBLISH FILES TO LABEL REPO
# ─────────────────────────────────────────────

LABEL_REPO.mkdir(parents=True, exist_ok=True)

shutil.copy2(homepage_output, LABEL_REPO / "homepage-data.json")
shutil.copy2(radio_output, LABEL_REPO / "radio-data.json")

print()
print("Published homepage-data.json")
print("Published radio-data.json")

print()
print("===================================")
print(" ARTIST CREATED")
print("===================================")
print()
print("Next:")
print(f"  1. Run Build Artist Site for: {artist_id}")
print(f"  2. Run update.bat inside: {repo_path}")

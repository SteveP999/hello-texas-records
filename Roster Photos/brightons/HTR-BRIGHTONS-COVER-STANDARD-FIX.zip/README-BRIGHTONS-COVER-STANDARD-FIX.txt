HTR Brightons / Cover Standard Fix

Replace:
- D:\HTR-Control-Center\scripts\build-artist-site.py
- D:\HTR-Control-Center\scripts\create-artist.py

Fixes:
- Apostrophes no longer create broken slugs.
  Yesterday's Girl -> yesterdays-girl
- Create Artist now defaults song covers to:
  images/covers/<artist-id>-<song-slug>-cover.png
- Create Artist now writes albumCover as:
  images/covers/<artist-id>-<album-slug>-ALBUM-cover.png
- Quotation marks accidentally pasted into cover paths are stripped during build.

Then rebuild Brightons with HTR-MENU #4.

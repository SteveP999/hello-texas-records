HTR RADIO LOCAL COVER PUBLISH LOCK

This is the missing piece if local Radio Covers were created but not published.

Replace:
D:\HTR-Control-Center\scripts\build-radio-data.py

Copy:
publish-htr-radio-local-covers.bat
to:
D:\HTR-Control-Center\publish-htr-radio-local-covers.bat

Run:
publish-htr-radio-local-covers.bat

What this does:
1. Rebuilds D:\hello-texas-records\radio-data.json
2. Copies cover art into D:\hello-texas-records\Radio Covers\
3. Runs git add radio-data.json
4. Runs git add "Radio Covers"
5. Commits and pushes

Why this matters:
HTR-MENU option 9 may have published radio-data.json but not the newly created Radio Covers folder.
If the live site references Radio Covers/... but GitHub does not contain those files, the player stays broken.

This does not touch hellotexasradio.com or the FM dial.

@echo off
setlocal

echo ==================================================
echo HTR RADIO LOCAL COVER REBUILD + PUBLISH LOCK
echo ==================================================
echo This publishes radio-data.json AND the Radio Covers folder.
echo.

cd /d D:\HTR-Control-Center
py "scripts\build-radio-data.py"
if errorlevel 1 (
  echo.
  echo ERROR: build-radio-data.py failed.
  pause
  exit /b 1
)

echo.
echo ==================================================
echo GIT STATUS BEFORE PUBLISH
echo ==================================================
cd /d D:\hello-texas-records
git status --short

echo.
echo ==================================================
echo ADDING RADIO DATA + RADIO COVERS
echo ==================================================
git add radio-data.json
git add "Radio Covers"
git add radio-cover-build-report.txt

echo.
echo ==================================================
echo COMMITTING
echo ==================================================
git commit -m "Lock HTR Radio local cover assets"
if errorlevel 1 (
  echo.
  echo Nothing new to commit, or commit failed.
  echo Continuing to push in case prior commit exists.
)

echo.
echo ==================================================
echo PUSHING TO GITHUB
echo ==================================================
git push

echo.
echo ==================================================
echo DONE
echo ==================================================
echo Check GitHub repo to confirm Radio Covers folder exists online.
echo Then hard refresh HelloTexasRecords.com.
echo.
pause
endlocal

import json
import re
import shutil
from pathlib import Path
from urllib.parse import urlparse, unquote

ROOT = Path(r"D:\HTR-Control-Center")
DATA = ROOT / "data"
MAIN_REPO = Path(r"D:\hello-texas-records")

ARTISTS_FILE = DATA / "artists.json"
SONGS_FILE = DATA / "master-songs.json"
CONTROL_RADIO_FILE = DATA / "radio-data.json"
MAIN_RADIO_FILE = MAIN_REPO / "radio-data.json"
RADIO_COVERS_DIR = MAIN_REPO / "Radio Covers"

EXCLUDE_ARTIST_IDS = {"lucas-harlow", "neon-thunder"}
EXCLUDE_TITLE_PARTS = {"texxxas tales"}

FALLBACK_REPOS = {
    "hello-texas": "Hello-Texas",
    "avery-ivey": "Avery-Ivey",
    "ivey-wilder": "Ivey-Wilder",
    "daniel-kincaid": "Daniel-Kincaid",
    "lucas-harlow": "Lucas-Harlow",
    "night-shift": "Night-Shift",
    "nightstrike": "NightStrike",
    "parsons-cross": "Parsons-Cross",
    "rio-valencia": "Rio-Valencia",
    "sawyer-price": "Sawyer-Price",
    "skyline-theory": "Skyline-Theory",
    "silent-oblivion": "Silent-Oblivion",
    "taylor-martin": "Taylor-Martin",
    "vincent-cole": "Vincent-Cole",
    "borrowed-whispers": "Borrowed-Whispers",
    "brightons": "Brightons",
    "vanta": "vanta",
    "pulse7": "pulse7",
    "stephen-parsons": "stephen-parsons",
}


def read_json(path, default):
    return json.loads(path.read_text(encoding="utf-8-sig")) if path.exists() else default


def write_json(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")


def clean(value):
    return str(value or "").strip().strip('"').strip("'").replace("\\", "/")


def is_url(value):
    return bool(re.match(r"^https?://", str(value or ""), flags=re.I))


def slugify(text):
    text = str(text or "").lower()
    text = text.replace("&", "and")
    text = text.replace("'", "").replace("’", "").replace("‘", "")
    text = re.sub(r"[^a-z0-9]+", "-", text)
    return text.strip("-")


def repo_slug_for_song(song, artist_lookup):
    artist_id = (song.get("artistId") or "").strip()
    artist = artist_lookup.get(artist_id, {})

    repo = clean(artist.get("githubRepo") or artist.get("repo") or artist.get("repoName") or "")
    if repo:
        return repo.split("/")[-1]

    repo_folder = clean(artist.get("repoFolder") or artist.get("repoPath") or "")
    if repo_folder:
        return repo_folder.rstrip("/").split("/")[-1]

    return FALLBACK_REPOS.get(artist_id, artist_id)


def artist_repo_folder(song, artist_lookup):
    artist_id = (song.get("artistId") or "").strip()
    artist = artist_lookup.get(artist_id, {})

    for key in ["repoFolder", "repoPath"]:
        value = artist.get(key)
        if value:
            p = Path(str(value))
            if p.exists():
                return p

    repo_slug = repo_slug_for_song(song, artist_lookup)
    candidates = [
        Path("D:/") / repo_slug,
        Path("D:/") / artist_id,
        Path("D:/") / slugify(song.get("artist") or artist_id),
    ]

    for p in candidates:
        if p.exists():
            return p

    return Path("D:/") / repo_slug


def path_from_raw_url(url):
    try:
        parsed = urlparse(url)
    except Exception:
        return ""

    parts = [unquote(p) for p in parsed.path.split("/") if p]
    if "raw.githubusercontent.com" in parsed.netloc and len(parts) >= 4:
        return "/".join(parts[3:])

    if "github.com" in parsed.netloc and len(parts) >= 5 and parts[2] == "blob":
        return "/".join(parts[4:])

    return ""


def possible_local_cover_paths(song, artist_lookup):
    repo = artist_repo_folder(song, artist_lookup)
    raw = clean(song.get("coverImage") or song.get("cover") or song.get("image") or "")
    title_slug = slugify(song.get("title") or "")
    artist_id = song.get("artistId") or ""
    filename = ""
    paths = []

    if raw:
        if is_url(raw):
            rel = path_from_raw_url(raw)
        else:
            rel = raw.lstrip("./")

        if rel:
            paths.append(repo / rel)

            # Drift bridges.
            if rel.startswith("covers/"):
                paths.append(repo / "images" / rel)
            if rel.startswith("images/covers/"):
                paths.append(repo / rel.replace("images/", "", 1))

            filename = Path(rel).name

    if filename:
        paths.extend([
            repo / "images" / "covers" / filename,
            repo / "covers" / filename,
        ])

    if artist_id and title_slug:
        for ext in [".png", ".jpg", ".jpeg", ".webp"]:
            paths.extend([
                repo / "images" / "covers" / f"{artist_id}-{title_slug}-cover{ext}",
                repo / "covers" / f"{artist_id}-{title_slug}-cover{ext}",
                repo / "images" / "covers" / f"{artist_id}-{title_slug}-SONG-cover{ext}",
                repo / "covers" / f"{artist_id}-{title_slug}-SONG-cover{ext}",
            ])

    seen = set()
    out = []
    for p in paths:
        key = str(p).lower()
        if key not in seen:
            seen.add(key)
            out.append(p)
    return out


def copy_cover_to_main(song, artist_lookup):
    artist_id = (song.get("artistId") or "unknown-artist").strip()
    song_id = slugify(song.get("id") or song.get("title") or "track")

    for src in possible_local_cover_paths(song, artist_lookup):
        if src.exists() and src.is_file():
            ext = src.suffix or ".png"
            safe_name = f"{song_id}{ext}"
            dest = RADIO_COVERS_DIR / artist_id / safe_name
            dest.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(src, dest)
            return clean(dest.relative_to(MAIN_REPO))

    return ""


def preserve_or_localize_cover(song, artist_lookup):
    local = copy_cover_to_main(song, artist_lookup)
    if local:
        return local

    for key in ["coverImage", "cover", "image"]:
        value = clean(song.get(key))
        if value:
            return value

    return ""


def should_include(song):
    if (song.get("artistId") or "") in EXCLUDE_ARTIST_IDS:
        return False

    title = (song.get("title") or "").lower()
    album = (song.get("album") or "").lower()
    if any(x in title or x in album for x in EXCLUDE_TITLE_PARTS):
        return False

    if song.get("includeOnRadio", True) is False:
        return False

    return bool(song.get("audioFile") or song.get("audioSrc") or song.get("audio"))


def main():
    artists = read_json(ARTISTS_FILE, [])
    artist_lookup = {a.get("id", ""): a for a in artists}
    songs = read_json(SONGS_FILE, [])

    if not MAIN_REPO.exists():
        raise SystemExit(f"Main repo not found: {MAIN_REPO}")

    tracks = []
    copied = 0
    kept_external = 0
    missing_cover = []

    for song in songs:
        if not should_include(song):
            continue

        audio = song.get("audioFile") or song.get("audioSrc") or song.get("audio") or ""
        cover = preserve_or_localize_cover(song, artist_lookup)

        if cover.startswith("Radio Covers/"):
            copied += 1
        elif cover:
            kept_external += 1
        else:
            missing_cover.append(f"{song.get('artist')} - {song.get('title')}")

        tracks.append({
            "id": song.get("id", ""),
            "artist": song.get("artist", ""),
            "artistId": song.get("artistId", ""),
            "title": song.get("title", ""),
            "album": song.get("album", ""),
            "genre": song.get("genre", ""),
            "coverImage": cover,
            "cover": cover,
            "audioFile": audio,
            "audioSrc": audio,
            "youtubeUrl": song.get("youtubeUrl", ""),
            "videos": song.get("videos", []),
            "explicit": song.get("explicit", False),
            "tags": song.get("tags", []),
        })

    write_json(CONTROL_RADIO_FILE, tracks)
    write_json(MAIN_RADIO_FILE, tracks)

    report = MAIN_REPO / "radio-cover-build-report.txt"
    report.write_text(
        "\n".join([
            "HTR RADIO LOCAL COVER BUILD REPORT",
            f"Tracks written: {len(tracks)}",
            f"Covers copied into HelloTexasRecords.com: {copied}",
            f"External cover URLs preserved: {kept_external}",
            f"Missing covers: {len(missing_cover)}",
            "",
            "Missing cover list:",
            *[f"- {x}" for x in missing_cover]
        ]),
        encoding="utf-8"
    )

    print("HTR RADIO LOCAL COVER LOCK COMPLETE")
    print(f"Tracks written: {len(tracks)}")
    print(f"Covers copied into HelloTexasRecords.com: {copied}")
    print(f"External cover URLs preserved: {kept_external}")
    print(f"Missing covers: {len(missing_cover)}")
    print(f"Report: {report}")


if __name__ == "__main__":
    main()

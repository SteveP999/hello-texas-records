@echo off
cd /d D:\HTR-Control-Center
py "scripts\build-radio-data.py"
echo.
echo If the copy count is high, publish HelloTexasRecords.com with HTR-MENU option 9.
echo.
pause

HTR RADIO LOCAL COVER LOCK

Replace:
D:\HTR-Control-Center\scripts\build-radio-data.py

Copy:
lock-htr-radio-local-covers.bat
to:
D:\HTR-Control-Center\lock-htr-radio-local-covers.bat

Run:
lock-htr-radio-local-covers.bat

Then:
HTR-MENU.bat -> 9. Publish HelloTexasRecords.com Repo

What this does:
- Rebuilds D:\HTR-Control-Center\data\radio-data.json.
- Rebuilds D:\hello-texas-records\radio-data.json.
- Copies song cover images from each artist repo into:
  D:\hello-texas-records\Radio Covers\<artist-id>\<song-id>.png/jpg/etc.
- Sets coverImage to the copied local file:
  Radio Covers/<artist-id>/<song-id>.png

Why this is the better lock:
The old system depended on mixed GitHub raw paths:
- /covers/
- /images/covers/
- older nested album folders
- newer standardized folders

That is why only a few covers worked after rebuilds.
This local copy lock makes HelloTexasRecords.com carry its own radio cover assets.
Artist repos remain source material, but the homepage radio no longer breaks when artist repo paths drift.

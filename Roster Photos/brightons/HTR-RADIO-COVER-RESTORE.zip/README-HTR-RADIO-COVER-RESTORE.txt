HTR Radio Cover Restore

Replace:
D:\HTR-Control-Center\scripts\build-radio-data.py

Then run:
HTR-MENU.bat -> Rebuild Radio Data
HTR-MENU.bat -> Publish HelloTexasRecords.com Repo

What this fixes:
- HTR Radio runs from HelloTexasRecords.com.
- Artist cover paths like images/covers/... do not work there unless the image exists in the main repo.
- This builder now converts song covers and album covers to raw GitHub URLs from each artist repo.
- It writes coverImage, cover, albumCover, and albumArt for compatibility.

This does not touch artist sites.

HTR Records Homepage Radio Client Path Fix

This fixes ONLY the HelloTexasRecords.com bottom/random HTR Radio player.

Replace:
D:\hello-texas-records\homepage-app.js
D:\HTR-Control-Center\scripts\build-radio-data.py

Then run:
HTR-MENU.bat -> Rebuild Radio Data
HTR-MENU.bat -> Publish HelloTexasRecords.com Repo

Why this version is different:
- If radio-data.json still contains artist-relative paths like images/covers/..., the live homepage JS now converts them to raw GitHub URLs in the browser.
- That means it works even if the data file was not fully repaired yet.
- It uses homepage-data.json artist githubRepo values when available.
- It falls back to known repo names for existing artists.
- This does NOT touch hellotexasradio.com or the FM dial system.
